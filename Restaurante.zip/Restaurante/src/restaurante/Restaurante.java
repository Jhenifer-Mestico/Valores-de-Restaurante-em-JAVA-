/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

/**
 *
 * @author Jhenifer
 */
import javax.swing.JOptionPane;
import java.util.Scanner;
public class Restaurante {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double gastocliente,resultado,valorcliente;
        
        Scanner inputData = new Scanner(System.in);
    System.out.println("Digite  valor gasto pelo cliente em R$:");
    gastocliente = inputData.nextDouble(); 
    
      resultado = gastocliente/10;
      
    System.out.println("Valor a ser pago com 10% do garçon:" +gastocliente+ resultado);
   valorcliente = inputData.nextDouble(); 
   
    }
    
}
